jQuery(document).ready(function($) {
	if ($("#pdWooTrcOrdrDatePicker").length) {
		$("#pdWooTrcOrdrDatePicker").datepicker({
			dateFormat : "dd-mm-yy"
		});
	}
});