<?php

# Silence is Gold